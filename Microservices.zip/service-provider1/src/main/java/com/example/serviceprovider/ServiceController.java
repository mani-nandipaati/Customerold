package com.example.serviceprovider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceController {

	@Autowired
	private DiscoveryClient discoveryClient;


	@ResponseBody
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public String getTest(){
		System.out.println("inside SP1 TEST");
		return "SP! TEST";
	}
}